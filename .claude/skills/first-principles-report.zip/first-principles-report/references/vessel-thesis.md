# Vessel Investment Thesis — The Displacement Framework

*This is the analytical heart of the First Principles Report. Every section of every report is an application of the ideas below.*

## Core definitions

- **Value:** The first principle the whole thesis is built on. Value is defined as *time*, and currency as the proxy for time (a store of value). When assessing any technology, value is ultimately measured in time saved, money saved (money being stored time), or money enabled.
- **Displacement:** Borrowed from physics — the change in an object's position from a start point to an end point. In markets, we analyze the displacement of *market buyers*: moving them from their current solution (the status quo) to a new one.
- **Status Quo:** The existing state of affairs — the prevailing conditions and choices available to buyers before any new entrant intervenes.
- **Cost:** Not just price. Cost incorporates the price paid, the time invested, and the return on investment for both.

## Value as a first principle

Humans trade time for currency (labor → money), so currency is stored time. Every person continuously spends time and money to receive a set of experiences — their **Net Reality**, the summation of their value-based decisions.

People rebalance toward a **net positive reality**: the same or better experience for less time/money, a better experience for the same time/money, or a far better experience for more. A **net negative reality** is the inverse. People optimize toward net positive reality and away from net negative.

(The chicken-wings example: if two restaurants charge the same, you go to the better one. If a new place opens with better wings at a lower price, you switch fast. If it has worse wings at a higher price, you try once and never return.)

## Net Reality in markets

In any market, the offerings of existing sellers (quality, price, time, etc.) form the **status quo** of choices. The key agreements between buyers and sellers are **value transactions** — price, time commitment, quality, atmosphere, UX, and more. Each market has a handful of key value transactions that define its status quo.

This is visualized on an X/Y graph:
- **Y axis = Cost.** Moving UP means lower cost (lower price, less time, higher ROI).
- **X axis = Experience.** Moving RIGHT means better experience (better product/service, interface, relationship).
- The **Status Quo sits at the origin**, where the axes cross.

This works for both B2C and B2B. For businesses: value is the time and capital all stakeholders invest to produce what they sell; net reality is the organization's holistic set of process/tool decisions; value transactions are what a business buyer expects for its budget.

## Market displacement

Every new entrant (a startup) is fundamentally attempting **displacement**: pulling a meaningful number of buyers away from the status quo to build a viable, profitable business.

Displacement only happens when the entrant delivers **new value transactions that improve on the status quo** for the value invested — a movement **up and to the right** on the graph, creating a **positive net reality**.

- Positive movement on **one** axis makes displacement *possible* (e.g., a much better experience at the same price).
- Positive movement on **both** axes makes displacement *probable*.
- **The inverse is critical:** if a new entrant cannot deliver a net positive reality, it will almost certainly fail. It may win some customers via marketing, but if the status quo is better, buyers stay.

## The three zones

Positive value movements are categorized into three zones:

- **Zone 1 — Incremental.** Small movement on both axes (e.g., 5% cheaper, marginally better). Businesses can survive here, but it is where incumbents compete with each other — dangerous for a new entrant, because an incumbent can easily match the offering.
- **Zone 2 — Significant on one axis.** A large improvement on one axis with incremental change on the other (e.g., the same experience at 50% of the price). Viable; usually requires technology or business-model leverage.
- **Zone 3 — Significant on both axes.** A large improvement on both experience AND cost. These are the venture-scale opportunities. Zone 3 in a large market gives the highest probability of venture-scale returns.

## Enabling displacement: inertia and forces

In physics, inertia keeps an object still until a force greater than what holds it in place is applied. In markets, **inertia is the buyer's resistance to change** — people don't like to change, and the status quo has gravity. Displacement requires a **push or pull force** strong enough to overcome that inertia.

- **Push force:** external pressure, e.g., regulatory change that forces new behavior.
- **Pull force:** a compelling set of new value transactions that creates a significantly better experience at lower cost, attracting buyers. Venture investing focuses mostly on pull forces.

The harder a market is to move (the higher its inertia — entrenched data, habits, integrations, switching costs), the stronger the value transactions must be to move it.

Two levers create pull forces:
- **Business model** (the weaker lever alone): rebuilding how things are done, e.g., shifting from large upfront cost to a recurring subscription. Powerful mainly when coupled with technology.
- **Technology** (the primary lever): new technologies (the engine, the internet, low-cost sensors, AI, etc.) let entrepreneurs build fundamentally new alternatives that deliver far better experience at lower cost. This is the strong lever.

## In practice — how Vessel analyzes (maps directly to the report sections)

Vessel invests at or near the **application layer** of the value chain — it must understand how the *end user* will experience a new net positive reality, because success at the application layer drives full displacement.

The process:
1. **Understand emerging technology** — including the nuance of "claims versus actual performance."
2. **Dissect the status quo** — the key value transactions between sellers and buyers, and the buyer's day-to-day net reality.
3. **Compare value transactions** — the most critical stage. Compare the status quo's value transactions to the new ones the startup aspires to deliver. The driving question: *if the startup delivers on its speculative claims, to what degree will it create a significantly better experience at lower cost, such that adoption becomes a no-brainer for buyers?*
4. **Analyze displacement process and risk** — the detailed path of leaving the status quo and adopting the new technology, and the friction in it (regulatory approval, disentangling enterprise systems, career risk, etc.).
5. **Chart new entrants** — map competitors, compare value claims, assess whether it's winner-take-all/most/some.
6. **Assess the team** — conviction that this team can turn speculative claims into reality.
7. **Capitalization strategy** — the right capital structure for the risk/reward.

## The bottom line

The framework distills complex systems to one test: **if the market buyer's life is not significantly improved, you have no market.** That sentence is the honesty mandate for every report.
