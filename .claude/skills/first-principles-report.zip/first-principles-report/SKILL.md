---
name: first-principles-report
description: Generate a Vessel-style "First Principles Report" analyzing a university or early-stage technology for market displacement opportunity. Use this skill whenever the task involves turning an intellectual-property disclosure, patent, or research technology into an investment-style memo, evaluating a technology's commercialization or displacement potential, writing up an Ohio State (or other university) technology, or producing the structured report that powers the IP commercialization platform. Trigger this for any request to analyze, evaluate, or write a report on a technology's market opportunity, even if the user does not say "first principles report" by name.
---

# First Principles Report

This skill produces a **First Principles Report**: a structured, intellectually honest analysis of whether a technology represents a real market *displacement* opportunity. It is the core deliverable of the Ohio State IP commercialization platform.

The report is modeled on the Vessel investment thesis and written in the style of the Airtrek investment memo. Before doing anything else, **read the three reference files** — they are the foundation of every report:

- `references/vessel-thesis.md` — **the heart of this skill.** The displacement framework, the zones, the concept of value, and the analytical lens that governs every judgment. Internalize this completely; every section of the report is an application of it.
- `references/airtrek-memo.md` — **the style and structure example.** A polished, well-written report on a real company. Match its writing quality, tone, section logic, and format. (Note: Airtrek is an operating company, so it includes product/pricing detail most university technologies will not have — copy its *craft*, not its assumption of a mature product.)
- `references/diamond-report.md` — **the worked example.** A finished report on a pre-product university technology (DIAMOND), demonstrating how to apply every rule below to a real, early-stage, unproven case. This is the closest analog to most technologies you will analyze.

## The single most important idea

**The report's job is to determine whether real displacement opportunity exists in a technology, and to explain why or why not. It is NOT to grade the technology.**

This distinction governs everything. A report that says "here is what the technology is and how good it is" has failed. A report that says "here is the market, here is specifically where it falls short, and here is whether this technology fills that gap" has succeeded.

Follow the Airtrek logic precisely: the **Status Quo** section establishes the market and pinpoints *where it falls short*; the **New Value Transactions** section shows whether and how the technology fills that specific hole. The whole analysis is gap-then-fill.

**Never default to "large incumbents dominate, so there is no opportunity."** That is lazy and defeats the purpose of the tool. Entrenched incumbents ARE the status quo in every market worth entering; the entire point of displacement (and of Zone 3) is unseating strong incumbents. Actively hunt for the displacement angle, steelman it, and only then judge how strong it is. If a real opportunity exists, find it and expand on it. If it genuinely does not, say so plainly. Both are valuable outcomes.

## Core principle: intellectual honesty

Be neutral and matter-of-fact — never optimistic, never pessimistic. If a technology has no viable displacement opportunity, say so plainly; that is a correct and useful result, not a failure. You are assessing whether displacement *is possible*, not trying to make it work. As the thesis puts it: if the buyer's life is not significantly improved, there is no market.

Be blunt about the technology and the market, but respectful of the people. Assess the work honestly; never editorialize about the researcher. Frame weaknesses as market and evidence realities, not as judgments of the inventor — a researcher reading their own report should get the truth without a sting.

## Research first — then write

The quality of the report depends entirely on the research behind it, and **all research must be done and verified BEFORE writing begins.** Researching reactively while writing produces errors that propagate across sections. Lock the facts first, then write once.

Rules learned the hard way:

- **Match inventor names before attributing any patent.** A patent on a similar topic is NOT this technology's patent unless the inventor names match. When no patent is found, state that as a finding — do not reach for a plausible-looking one.
- **Handle missing data honestly.** Many university technologies lack a public disclosure date, patent, or TRL. Label these as unconfirmed or as estimates; never invent certainty. "Not published; earliest public activity ~2018" beats a confident guess.
- **Facts are load-bearing.** When a key fact changes during research, re-check every section that depends on it. One wrong fact corrupts the whole analysis.
- **Research the promising angle hard.** When you identify a possible displacement opportunity, research whether it is genuinely unsolved or already addressed by the market. Do not assume an angle is open (or closed) without checking.
- **Frame the technology as it actually is.** If a technology integrates several functions, analyze the integrated whole, not each piece in isolation — the combination may be where the opportunity (or its absence) lives.

## The research checklist (complete before writing)

1. The technology itself — what it is and how it works mechanically (from the source disclosure).
2. The inventor(s) — credentials, domain standing, founder/commercial experience, right to win.
3. Patent status — search by inventor name; confirm matches; report honestly if none found.
4. Disclosure date and commercialization traction — find if public; label if not.
5. The status quo market — who the buyers are, who the sellers are, what is already solved well.
6. Where the status quo falls short — the specific gap(s) the technology might address.
7. The competitive landscape for that specific gap — is it genuinely unsolved, or contested?

## The three independent axes

Assess each independently, on its own evidence. They may correlate, but **none is derived from another**, and the report should interpret what their combination means rather than forcing them to align.

- **TRL (Technology Readiness Level, 1–9):** how technically mature the technology is. Assess from demonstrated evidence; if maturity is unclear, give a range. Most university IP sits at TRL 2–4. (Reported in the Details block.)
- **Confidence score (1–10):** confidence in the technology's realistic *displacement* performance, weighing all factors together — mechanism credibility, market position, differentiation, validation evidence, team, and age. No single factor (age included) may dominate. (Woven into the Value Overview prose — see formatting.)
- **Zone (1, 2, 3, or none):** the *kind* of displacement, from the thesis. Zone 1 = incremental on both axes (dangerous; incumbents match easily). Zone 2 = large gain on one axis. Zone 3 = large gain on both (the venture prize). (Stated in the Thesis Analysis Summary.)

A low TRL with high confidence is a coherent and often exciting profile (early but promising). Do not drag confidence down just because TRL is low.

## Report structure

Follow this exact structure, matching the Airtrek memo's format and the DIAMOND worked example.

```
# First Principles Report: [Name]
**[Tech ID] · [Full Name]**

## Technology Related Links
- OSU web link, patent filings (or honest "none found"), inventor research record, decks/whitepapers

## Technology Overview
2–4 paragraphs explaining what the technology is and how it works. Just explain the
technology clearly — do not hedge every sentence with "as described in the source." Identify
which of its functions are novel vs. commoditized, as that points to where opportunity may lie.

## The Details
A table: Technology | Principal Researcher | Secondary Researchers | College | Date Disclosed
| Current Commercialization Traction | Technology Readiness Level (with brief evidence-based
justification).

## Thesis Analysis
*Intro line referencing the Vessel thesis.*

### 0. Application Selection
1–2 paragraphs. If the source names a clear application, use it; otherwise select the most
practical/commercial one and justify. Pick one and commit.

### 1. Status Quo
Establish the market in detail: who the buyer is, what they buy, who they buy from, what the
status quo already does WELL — and, critically, pinpoint where it falls short. The gap you
identify here is what the next section tests the technology against. This is the most important
section; spend the most detail here.

### 2. New Value Transactions
Show whether and how the technology fills the specific gap identified in the Status Quo. This is
the gap-then-fill heart of the report. Be honest about whether this is a demonstrated result or a
speculative claim. A short bulleted list of the key new value transactions (Airtrek-style) can
sharpen this section.

### 3. Value Overview
1–2 paragraphs of prose explaining how the technology saves the buyer time, saves them money,
or helps them make more money. Do NOT use the three questions as headers or bullets — they are
your internal checklist. If the technology does not do one of these, explain that. Weave the
confidence score into the prose here as a number in natural language (e.g., "this is roughly a
5 out of 10 on displacement confidence, because…") — never as a bolded "Confidence Score:" label.

### 4. Displacement Process & Risks
What a buyer must do to leave the status quo and adopt this technology, and the friction in that
path — switching costs, integration, regulatory/procurement cycles, trust, validation burden.
The harder the market is to move (inertia), the stronger the value must be to move it. Bullets or
short paragraphs, matching Airtrek's format.

### 5. Team Overview
Bulleted, like the Airtrek memo. The inventor's credentials, domain standing, relevant
experience, and the honest commercial gap (typically: strong researcher, no operating team / no
IP). Note that closing that gap is exactly the researcher-to-operator bridge the program exists
to create.

### 6. New Entrants
Who else is attacking the same gap. Is it genuinely open, or contested? Winner-take-all/most/some?
Validate the opportunity honestly — heavy competition confirms the opportunity is real but raises
the bar.

### 7. Thesis Analysis Summary
Synthesize against the thesis. State the realistic movement on the cost and experience axes,
classify the Zone, and weave together all three independent axes (TRL, confidence, Zone) into a
coherent verdict. Express the confidence number in prose, Airtrek-style. End with the single
decisive question the opportunity hinges on.
```

## Writing style

Match the Airtrek memo: clear, declarative, well-organized prose. Confident in stating what is known, honest about what is not. Use concrete figures wherever they are verifiable (market sizes, documented gaps, real statistics) — but never invent figures (pricing, traction, performance) a pre-product technology does not have. Avoid hedging filler like "as described in the available material" or "on the evidence available" in the overview; just explain the technology. Keep the tone neutral throughout — the honesty mandate is about accuracy, not severity.

## A note on pre-product technologies

Most technologies analyzed will be early-stage research, not operating companies like Airtrek. They will lack pricing, traction, a founding team, and often a patent. This is normal. Use the DIAMOND report as the model for handling this: anchor to a chosen application, assess the speculative claim honestly, find the real opportunity if one exists, and be candid about what is unproven. Do not fabricate company-stage detail to fill the Airtrek template.
